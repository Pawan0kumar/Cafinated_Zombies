package com.online_eventplanner.Dao;

import com.online_eventplanner.Model.Event;
import com.online_eventplanner.Model.QuotationRequest;

import java.util.ArrayList;
import java.util.List;

public class EventDaoImpl implements EventDao {
    private List<Event> eventList;

    public EventDaoImpl() {
        eventList = new ArrayList<>();
    }

    public Event createEvent(Event event) {
        // Simulate event creation by adding it to the list
        eventList.add(event);
        // Return the created event (in a real implementation, you might set the event ID)
        return event;
    }

    public Event updateEvent(Event event) {
        // Implement event update logic here
        return event;
    }

    public Event getEventById(int eventId) {
        // Implement logic to retrieve an event by its ID
        for (Event event : eventList) {
            if (event.getEventId() == eventId) {
                return event;
            }
        }
        return null; // Event not found
    }

    public List<Event> getAllEvents() {
        // Return all events in the list
        return eventList;
    }

    public void deleteEvent(int eventId) {
        // Implement logic to delete an event by its ID
        Event eventToRemove = null;
        for (Event event : eventList) {
            if (event.getEventId() == eventId) {
                eventToRemove = event;
                break;
            }
        }
        if (eventToRemove != null) {
            eventList.remove(eventToRemove);
        }
    }

    public QuotationRequest generateQuotation(int eventId, int userId, String message) {
        // Implement quotation generation logic here
        // This method is used for quotation requests, and you can handle it as needed
        return null;
    }
}
