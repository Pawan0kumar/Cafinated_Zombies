package com.online_eventplanner.Model;

public class QuotationRequest {

	private int requestId;
	private int eventId;
	private int userId;
	private String message;

	public QuotationRequest() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public QuotationRequest(int requestId, int eventId, int userId, String message) {
		super();
		this.requestId = requestId;
		this.eventId = eventId;
		this.userId = userId;
		this.message = message;
	}

}
