package com.online_eventplanner.Dao;

import com.online_eventplanner.Model.User;

public interface UserDao {
	User createUser(User user);

	User updateUser(User user);

	User getUserById(int userId);

	User getUserByEmail(String email);

	void deleteUser(int userId);
}
