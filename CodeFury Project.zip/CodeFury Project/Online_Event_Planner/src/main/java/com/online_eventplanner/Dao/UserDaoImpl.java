package com.online_eventplanner.Dao;

import com.online_eventplanner.Model.User;

import java.util.ArrayList;
import java.util.List;

public class UserDaoImpl implements UserDao {
    // Placeholder list to simulate user data storage
    private List<User> userList;

    public UserDaoImpl() {
        // Initialize the list (simulating user data storage)
        userList = new ArrayList<User>();
    }

    public User createUser(User user) {
        // Simulate creating a user in the database or data storage
        userList.add(user);
        return user;
    }

    public User getUserById(int userId) {
        // Simulate retrieving a user from the database by ID
        for (User user : userList) {
            if (user.getUserId() == userId) {
                return user;
            }
        }
        return null; // User not found
    }

    public void deleteUser(int userId) {
        // Simulate deleting a user from the database or data storage
        User userToRemove = null;
        for (User user : userList) {
            if (user.getUserId() == userId) {
                userToRemove = user;
                break;
            }
        }
        if (userToRemove != null) {
            userList.remove(userToRemove);
        }
    }

	public User updateUser(User user) {
		// TODO Auto-generated method stub
		return null;
	}

	public User getUserByEmail(String email) {
		// TODO Auto-generated method stub
		return null;
	}

}
