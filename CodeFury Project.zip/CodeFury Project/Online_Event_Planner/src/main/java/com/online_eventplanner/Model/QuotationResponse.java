package com.online_eventplanner.Model;

public class QuotationResponse {
    private String vendorName;
    private double price;
    private boolean availability;

    public QuotationResponse(String vendorName, double price, boolean availability) {
        this.vendorName = vendorName;
        this.price = price;
        this.availability = availability;
    }

    public String getVendorName() {
        return vendorName;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public boolean getAvailability() {
        return availability;
    }

    public void setAvailability(boolean availability) {
        this.availability = availability;
    }
}
