package com.online_eventplanner.Business;

import java.util.List;

import com.online_eventplanner.Exception.InvalidQuotationResponseException;
import com.online_eventplanner.Exception.QuotationRequestException;
import com.online_eventplanner.Model.Event;
import com.online_eventplanner.Model.QuotationRequest;

public interface EventService {
	Event createEvent(Event event);

	Event updateEvent(Event event);

	Event getEventById(int eventId);

	List<Event> getAllEvents();

	void deleteEvent(int eventId);

	QuotationRequest generateQuotation(int eventId, int userId, String message) throws QuotationRequestException, InvalidQuotationResponseException;

	com.online_eventplanner.Model.QuotationResponse generateQuotation(QuotationRequest quotationRequest);

	// Additional methods for event-related operations, for future
}
