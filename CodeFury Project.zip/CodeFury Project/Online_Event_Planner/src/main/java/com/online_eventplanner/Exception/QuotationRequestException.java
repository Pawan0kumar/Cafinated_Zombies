package com.online_eventplanner.Exception;

public class QuotationRequestException extends Exception {
    public QuotationRequestException(String message) {
        super(message);
    }
}

