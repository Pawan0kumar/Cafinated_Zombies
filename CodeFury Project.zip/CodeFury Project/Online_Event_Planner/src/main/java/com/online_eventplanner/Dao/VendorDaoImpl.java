package com.online_eventplanner.Dao;

import com.online_eventplanner.Model.Vendor;

import java.util.ArrayList;
import java.util.List;

public class VendorDaoImpl implements VendorDao {
    // Placeholder list to simulate vendor data storage
    private List<Vendor> vendorList;

    public VendorDaoImpl() {
        // Initialize the list (simulating vendor data storage)
        vendorList = new ArrayList<Vendor>();
    }

    public Vendor createVendor(Vendor vendor) {
        // Simulate creating a vendor in the database or data storage
        vendorList.add(vendor);
        return vendor;
    }

    public Vendor getVendorById(int vendorId) {
        // Simulate retrieving a vendor from the database by ID
        for (Vendor vendor : vendorList) {
            if (vendor.getVendorId() == vendorId) {
                return vendor;
            }
        }
        return null; // Vendor not found
    }


    public void deleteVendor(int vendorId) {
        // Simulate deleting a vendor from the database or data storage
        Vendor vendorToRemove = null;
        for (Vendor vendor : vendorList) {
            if (vendor.getVendorId() == vendorId) {
                vendorToRemove = vendor;
                break;
            }
        }
        if (vendorToRemove != null) {
            vendorList.remove(vendorToRemove);
        }
    }

	public Vendor updateVendor(Vendor vendor) {
		// TODO Auto-generated method stub
		return null;
	}

	public Vendor getVendorByEmail(String email) {
		// TODO Auto-generated method stub
		return null;
	}

}
