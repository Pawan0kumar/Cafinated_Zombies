package com.online_eventplanner.Dao;

import com.online_eventplanner.Model.Event;
import com.online_eventplanner.Model.QuotationRequest;

import java.util.List;

public interface EventDao {
	Event createEvent(Event event);

	Event updateEvent(Event event);

	Event getEventById(int eventId);

	List<Event> getAllEvents();

	void deleteEvent(int eventId);

	QuotationRequest generateQuotation(int eventId, int userId, String message);
}
