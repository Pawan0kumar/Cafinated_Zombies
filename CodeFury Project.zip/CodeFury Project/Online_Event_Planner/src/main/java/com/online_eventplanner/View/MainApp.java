package com.online_eventplanner.View;

import java.util.Scanner;

import com.online_eventplanner.Business.EventService;
import com.online_eventplanner.Dao.EventDao;
import com.online_eventplanner.Dao.EventDaoImpl;
import com.online_eventplanner.Dao.UserDao;
import com.online_eventplanner.Dao.UserDaoImpl;
import com.online_eventplanner.Exception.EventCreationException;
import com.online_eventplanner.Exception.InvalidQuotationResponseException;
import com.online_eventplanner.Exception.QuotationRequestException;
import com.online_eventplanner.Impl.UserEventServiceImpl;
import com.online_eventplanner.Model.Event;
import com.online_eventplanner.Model.QuotationRequest;

public class MainApp {
    public static void main(String[] args) throws QuotationRequestException, InvalidQuotationResponseException {
        EventDao eventDao = new EventDaoImpl();
        UserDao userDao = new UserDaoImpl();
        EventService userEventService = new UserEventServiceImpl(eventDao, userDao);
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Options:");
            System.out.println("1. Create Event");
            System.out.println("2. Request Quotation");
            System.out.println("3. Exit");
            System.out.print("Select an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    Event event = createEvent(scanner);
                    try {
                        Event createdEvent = userEventService.createEvent(event);
                        System.out.println("Event created Successfully: " + createdEvent);
                    } catch (EventCreationException e) {
                        System.err.println("Event creation error: " + e.getMessage());
                    }
                    break;
                case 2:
                    QuotationRequest quotationRequest = requestQuotation(scanner);
				QuotationRequest quotationResponse = userEventService.generateQuotation(quotationRequest.getEventId(),
				        quotationRequest.getUserId(), quotationRequest.getMessage());
				System.out.println("Quotation request successful: " + quotationResponse);
                    break;
                case 3:
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid option. Please select a valid option.");
            }
        }
    }

    // Other methods remain the same




    private static Event createEvent(Scanner scanner) {
        System.out.print("Enter event name: ");
        String name = scanner.nextLine();
        System.out.print("Enter event location: ");
        String location = scanner.nextLine();
        System.out.print("Enter event date (YYYY-MM-DD): ");
        String date = scanner.nextLine();
        System.out.print("Enter event time (HH:MM): ");
        String time = scanner.nextLine();
        System.out.print("Enter event price: ");
        double price = scanner.nextDouble();
        scanner.nextLine();
        return new Event(1, name, location, date, time, price);
    }

    private static QuotationRequest requestQuotation(Scanner scanner) {
        System.out.print("Enter your message for quotation request: ");
        String message = scanner.nextLine();
        System.out.print("Enter your event ID: ");
        int eventId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        // Simulate gathering user information
        System.out.print("Enter your user ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter your name: ");
        scanner.nextLine();
        System.out.print("Enter your email: ");
        scanner.nextLine();

        return new QuotationRequest(eventId, userId, userId, message);
    }
}
