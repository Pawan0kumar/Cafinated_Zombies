package com.online_eventplanner.Impl;

import java.util.List;

import com.online_eventplanner.Business.EventService;
import com.online_eventplanner.Dao.EventDao;
import com.online_eventplanner.Dao.UserDao;
import com.online_eventplanner.Exception.EventCreationException;
import com.online_eventplanner.Exception.InvalidQuotationResponseException;
import com.online_eventplanner.Exception.QuotationRequestException;
import com.online_eventplanner.Model.Event;
import com.online_eventplanner.Model.QuotationRequest;
import com.online_eventplanner.Model.QuotationResponse;

public class UserEventServiceImpl implements EventService {
    private EventDao eventDao;
    private UserDao userDao;

    public UserEventServiceImpl(EventDao eventDao, UserDao userDao) {
        this.eventDao = eventDao;
        this.userDao = userDao;
    }

    public Event createEvent(Event event) throws EventCreationException {
        // Check if the event is valid (e.g., all required fields are set)
        if (event == null ||
                event.getEventName() == null || event.getEventName().isEmpty() ||
                event.getEventLocation() == null || event.getEventLocation().isEmpty() ||
                event.getEventDate() == null || event.getEventDate().isEmpty() ||
                event.getEventTime() == null || event.getEventTime().isEmpty() ||
                event.getEventPrice() <= 0.0) {
            throw new EventCreationException("Invalid event data. Please check the event details.");
        }

        // You can further validate event data here

        // Assuming eventDao is properly initialized and implemented
        Event createdEvent = eventDao.createEvent(event);

        if (createdEvent == null) {
            throw new EventCreationException("Event creation failed. Please try again.");
        }

        return createdEvent;
    }

    // Other methods remain the same

    public QuotationRequest generateQuotation(int eventId, int userId, String message)
            throws QuotationRequestException, InvalidQuotationResponseException {
        eventDao.getEventById(eventId);
        userDao.getUserById(userId);

        // Create and return a quotation request
        QuotationRequest quotationRequest = new QuotationRequest(eventId, userId, userId, message);
        // You can add additional details to the quotation request if needed

        // Simulate receiving a quotation response
        QuotationResponse quotationResponse = getQuotationResponse(quotationRequest);

        if (quotationResponse == null) {
            throw new InvalidQuotationResponseException("Invalid quotation response received.");
        }

        return quotationRequest;
    }

    private QuotationResponse getQuotationResponse(QuotationRequest quotationRequest) {
        // Simulate receiving a quotation response
        // Implement this method to get the actual quotation response
        return new QuotationResponse(null, 0, false/* Fill with actual data */);
    }

	@Override
	public Event updateEvent(Event event) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Event getEventById(int eventId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Event> getAllEvents() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteEvent(int eventId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public QuotationResponse generateQuotation(QuotationRequest quotationRequest) {
		// TODO Auto-generated method stub
		return null;
	}
}
